"""REVIVE: preservation-first photograph restoration research project."""

"""Image and experiment utilities."""

"""Hand-engineered damage analysis modules."""
